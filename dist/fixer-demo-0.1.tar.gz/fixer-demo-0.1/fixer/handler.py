def hello():
    print('Hello Gambo')
