from setuptools import setup

setup(
    name='fixer-demo',
    version='0.1',
    description='Salam kardan b gambo ha',
    url='#',
    author='MT.ali',
    author_email='mr.tabatabaeiii@gmail.com',
    license='MIT',
    packages=['fixer'],
    zip_safe=False
)
